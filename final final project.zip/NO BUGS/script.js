

$('.second_fourth').on('click', function(){
    let text = document.querySelector('.advantages_1')
    let text2 = document.querySelector('.advantages_2')
    text.style.fontSize = "3vh";
    text.innerHTML = "эта картинка показывает мою трудолюбивость";
    text2.style.fontSize = "3vh";
    text2.innerHTML = "эта картинка показывает моё терпение";

})

$('.second_fourth2').on('click', function(){
    let text3 = document.querySelector('.advantages_3')
    let text4 = document.querySelector('.advantages_4')
    text3.style.fontSize = "3vh";
    text3.innerHTML = "эта картинка показывает мою готовность работать самому";
    text4.style.fontSize = "3vh";
    text4.innerHTML = "эта картинка показывает мою цель работать в большой компании";

})